%% initialization
clear; close all; clc

fprintf('loading data\n');
load('mnist-digits.mat');


fprintf('compute distance matrix using loops\n');
%time it
dist_loop=calc_dist_mat_loop_a_b(training, test);

fprintf('Program paused. Press enter to continue.\n');
pause

fprintf('compute distance matrix using vectors\n');
%time it
dist_squ=calc_dist_mat_squ_a_b(training, test);

% check if both functions return the same result
assert(all(all(dist_loop == dist_squ)));
fprintf('Program paused. Press enter to continue.\n');
pause

fprintf('use distance matrix to compute kNN for various values of k\n');
%%%% your code here %%%%

%%%%%%%%%%%%%%%%%%%%%%%%
 
fprintf('Program paused. Press enter to continue.\n');
pause
 
 
% bonus: 
%%%% your code here %%%%

%%%%%%%%%%%%%%%%%%%%%%%%

